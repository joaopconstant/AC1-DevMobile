package program;

public class CalculadoraImc {
    public String calcularImc(double peso, double altura, int idade, String sexo) {
        return "";
    }
}
